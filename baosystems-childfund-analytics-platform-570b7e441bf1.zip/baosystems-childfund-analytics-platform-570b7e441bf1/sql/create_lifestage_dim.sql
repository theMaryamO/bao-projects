/********************************************************************************
	Childfund Lifestage Dimension in BAO AP
	Target database = Azure Sql Database

	v1 - 20211206 - nevens@baosystems.com
	Simple junk dimension for lifestage enumeration.

********************************************************************************/

drop table if exists dim.lifestage;

select * into dim.lifestage from
(
	select -1			as LifestageKey
		, ''			as Lifestage
		, ''			as LifestageLabel
		, 0				as LifestageOrder
	union select 1	, 'LS1'	, 'Lifestage 1'	, 1
	union select 2	, 'LS2'	, 'Lifestage 2'	, 2
	union select 3	, 'LS3'	, 'Lifestage 3'	, 3
) u