/********************************************************************************
	Childfund School Type Dimension in BAO AP
	Target database = Azure Sql Database

	v1 - 20211206 - nevens@baosystems.com
	Dimension for School Type enumeration

********************************************************************************/

drop table if exists dim.school_type;

select * into dim.school_type from
(
	select
		distinct case school_type
			when 'public' then 1
			when 'private' then 2
			when 'non_formal' then 3
			when 'chose_not_to_answer' then 4
			when 'not_suredont_know' then 5
			else -1 end			as SchoolTypeKey
		, school_type			as SchoolTypeCode
		, case school_type
			when 'public' then 'Public'
			when 'private' then 'Private'
			when 'non_formal' then 'Non-Formal'
			when 'chose_not_to_answer' then 'Chose not to answer'
			when 'not_suredont_know' then 'Not sure/don''t know'
			else 'Unknown' end	as SchoolType
	from stg.all_global_me_survey
) u;