/********************************************************************************
	Childfund Region and Compulsory Age Map in BAO AP
	Target database = Azure Sql Database

	v1 - 20211206 - nevens@baosystems.com
	Lookups for Region to Country mapping
	   and Country to Compulsory Age thresholds
	   lifted from customer provided Word doc.

	   TODO: Country Ids in this version are placeholder.

********************************************************************************/

drop table if exists stg.region_and_compulsory_age_map;

select * into stg.region_and_compulsory_age_map from
(
	select 
		2					as RegionId
		, 'Americas'		as Region
		, 113				as CountryId
		, 'Bolivia'			as Country
		, 4					as LowerAge
		, 17				as UpperAge
	union select 2,	'Americas'	,110 , 'Brazil'			, 4	, 17
	union select 2,	'Americas'	,153 , 'Ecuador'		, 3	, 17
	union select 2,	'Americas'	,122 , 'Guatemala'		, 7	, 16
	union select 2,	'Americas'	,151 , 'Honduras'		, 6	, 15
	union select 2,	'Americas'	,125 , 'Mexico'			, 3	, 15
	union select 2,	'Americas'	,183 , 'US Programs'	, 5	, 17
	union select 1,	'Africa'	,144 , 'Ethiopia'		, 7	, 12
	union select 1,	'Africa'	,102 , 'The Gambia'		, 7	, 16
	union select 1,	'Africa'	,200 , 'Guinea'			, 7	, 13
	union select 1,	'Africa'	,145 , 'Kenya'			, 6	, 14
	union select 1,	'Africa'	,201 , 'Mozambique'		, 6	, 12
	union select 1,	'Africa'	,147 , 'Senegal'		, 6	, 16
	union select 1,	'Africa'	,198 , 'Sierra Leone'	, 6	, 14
	union select 1,	'Africa'	,149 , 'Uganda'			, 6	, 12
	union select 1,	'Africa'	,140 , 'Zambia'			, 7	, 13
	union select 3,	'Asia'		,500 , 'India'			, 6	, 14
	union select 3,	'Asia'		,132 , 'Indonesia'		, 6	, 15
	union select 3,	'Asia'		,135 , 'Philippines'	, 5	, 18
	union select 3,	'Asia'		,162 , 'Sri Lanka'		, 6	, 14
) u;