# README #

### How do I get set up? ###

Deploy/redeploy Sql views to AP. When creating and testing scripts, it's easiest to work in your Sql IDE of choice, e.g. SSMS, and once the script is finalized, redeploy the equivalent to the AP. The AP adds the 'create view' statement for you and adds a '_view' suffix to the name, so you need to account for this when copying the script from SSMS to AP.

For example, given the raw script beginning with

'''
create or alter view stg.all_child_cases_view as
select id
	, case_name
	, closed
	, source_module...
'''

the AP name would be entered as '''all_child_cases''', the schema selection would be '''stg''', and the script would omit the first line:

'''
select id
	, case_name
	, closed
	, source_module...
'''

Deployment sequence
1. create_all_child_cases_view.sql
   Update and/or recreate view in AP. Only required if there are changes.

2. create_all_global_me_survey_view.sql
   Update and/or recreate view in AP. Only required if there are changes.

3. rebuild_all_child_cases_table.sql
   Deploy directly to the database using your IDE (SSMS).

4. rebuild_all_global_me_survey_table.sql
   Deploy directly to the database using your IDE (SSMS).

5. Execute both stored procedures from your IDE. Expect this to take many minutes.
   
6. create_child_dim_view.sql
   Update and/or recreate view in AP. Only required if there are changes.

Static dimension tables to be executed directly against the database.
7. create_conducted_with_dim.sql
8. create_junk_dim.sql
9. create_reason_not_in_school.sql
10. create_region_and_compulsory_age_map.sql
11. create_school_type_dim.sql
    
12. create_location_dim_view.sql
    Update and/or recreate view in AP. Only required for changes.

13. global_survey_fact_view.sql
14. rebuild_date_dim
    Stored procedure which generates a date table. Only necessary if there have been changes or you want to change the date table range.