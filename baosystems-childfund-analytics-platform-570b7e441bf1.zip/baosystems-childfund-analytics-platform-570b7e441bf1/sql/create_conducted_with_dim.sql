/********************************************************************************
	Childfund 'Conducted With' Dimension in BAO AP
	Target database = Azure Sql Database

	v1 - 20211208 - nevens@baosystems.com
	Junk dimension/lookup to map CommCare response to readable form.

********************************************************************************/

drop table if exists dim.conducted_with;

select * into dim.conducted_with from
(
	select
		-1		as ConductedWithKey
		, ''	as ConductedWithCode
		, ''	as ConductedWith
	union select 1, 'child', 'Child or youth'
	union select 2, 'grandfather', 'Grandparent'
	union select 3, 'grandmother', 'Grandparent'
	union select 4, 'non-family_adult_caregiver', 'Non-related adult'
	union select 5, 'non-family_non-caregiver', 'Non-related adult'
	union select 6, 'other_adult_family_caregiver', 'Other family member'
	union select 7, 'sibling_or_other_non-adult_family_member', 'Other family member'
	union select 8, 'fatherstepfather', 'Parent'
	union select 9, 'motherstepmother', 'Parent'
) u