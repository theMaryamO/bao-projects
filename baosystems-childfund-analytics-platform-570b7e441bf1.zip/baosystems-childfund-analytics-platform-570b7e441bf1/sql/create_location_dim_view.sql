/********************************************************************************
	Childfund Location Dimension in BAO AP
	Target database = Azure Sql Database

	v1 - 20211206 - nevens@baosystems.com
	Preliminary Location dimension from CommCare (Kenya), Salesforce,
	  and Region table from Word doc.

	v2 - 2021120 - nevens@baosystems.com
	Brought in additional communities and implemented
		a temporary means of generating community id.

********************************************************************************/

-- TODO: join in Local Partner - ask Monica where to get Local Partner
create or alter view dim.location  as

select
	-- construct a deterministic, unique identifer for PK since
	--   an identity column won't help us within a view
	cast(
		concat(
			RegionId
			, case when CountryId != 0 then CountryId end
			, case when CommunityId != 0 then format(CommunityId, '0000') end
		) as int
	)														as LocationKey
	, *
	
	from
	(
		select

		  region.RegionId									as RegionId
		, region.Region										as Region
		, region.CountryId									as CountryId
		, coalesce(co_name, region.Country)					as Country
		, case when community_name is not null
			then row_number() over (partition by (select null) order by community_name)
			else 0 end										as CommunityId
		, coalesce(community_name, '')						as Community
		
		from
		(
			select distinct
				co_name
				, community_name
			FROM stg.all_global_me_survey cc
			union
			select distinct
				co_name
				, null
			FROM stg.all_global_me_survey
		) main

		full outer join
		(
			select RegionId
				, Region
				, CountryId
				, Country
				from stg.region_and_compulsory_age_map
			union
				select RegionId
				, Region
				, 0
				, ''
				from stg.region_and_compulsory_age_map
		) region
		on main.co_name = region.Country

	union

	-- Provide the default value if there is no location match
	select -1, '', 0, '', 0, ''
) keyq