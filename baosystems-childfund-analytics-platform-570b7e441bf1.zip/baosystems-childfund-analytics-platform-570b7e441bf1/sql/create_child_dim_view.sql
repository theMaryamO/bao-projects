/********************************************************************************
	ChildFund Child Dimension in BAO AP
	Target database = Azure Sql Database

	v1 - 20211203 - nevens@baosystems.com
	Intended to be deployed as an AP View which explains the use
		 of business key instead of identity, and lack of audit date
		 columns, SCD implementation

	v2 - 20211207 - nevens@baosystems.com
	Updated to reference views which union all country data
		instead of just Kenya

********************************************************************************/

/********************************************************************************
	Use both open and closed "type='child'" data from *_me_survey_cc
	CommCare form as the superset of all child records.
********************************************************************************/
create or alter view dim.child as
select 
	  distinct core.id									as ChildKey
	  , core.id											as CaseId
	  , coalesce(core.child_id, -1)						as ChildId
	  , source_module									as SourceModule
      , cast(core.closed as bit)						as Closed
      , trim(core.case_name)							as ChildName
	  , trim(core.child_first_name)						as FirstName
	  , trim(core.child_last_name)						as LastName
	  , core.child_date_of_birth						as Birthdate
	  , cast(case when round(core.age,0) < 0 then null
			when len( core.child_date_of_birth ) = 5 then
				dateadd( day, cast( core.child_date_of_birth as int), '1900-01-01' )
			when len( core.child_date_of_birth ) = 11 then
				dateadd( minute, convert(int, (cast(core.child_date_of_birth as bigint)-12190023480)/60.0), '1970-01-01' )
			else cast( core.child_date_of_birth as date)
			end as date)								as CalculatedBirthdate
	  , round(core.age,0)								as AgeFromCase
	  , cast(datediff( 
			month, cast(case when round(core.age,0) < 0 then null
			when len( core.child_date_of_birth ) = 5 then
				dateadd( day, cast( core.child_date_of_birth as int), '1900-01-01' )
			when len( core.child_date_of_birth ) = 11 then
				dateadd( minute, convert(int, (cast(core.child_date_of_birth as bigint)-12190023480)/60.0), '1970-01-01' )
			else cast( core.child_date_of_birth as date)
			end as date),
		cast( case when core.created_date = '#NULL!' then null
			when core.created_date = '30/11/-0001' then null
			when len(core.created_date) = 10
				then core.created_date end as date)
		) / 12.0 as decimal(5,2))						as AgeAtRegistration
	  ,	coalesce(upper(left(
			core.sex
			,1)) + 
				lower(right(
				core.sex
			, len(core.sex
		)-1)), 'Unknown')								as Sex
	  , coalesce(upper(
			left(
					core.sex
				, 1)
		), 'U')											as SexFl
	  , coalesce(core.ethnicity, 'Unknown')				as Ethnicity
      , coalesce(core.language, 'Unknown')				as Language
      , coalesce(core.education_level, 'Unknown')		as Education
      , coalesce(core.sponsorship_status, 'Unknown')	as SponsorshipStatus
		--AV - Available
		--CM - Check Materials
		--EN - Enrolled
		--PS - Pre-Sponsored
		--RE - Reinstateable
		--RV - Reserved
		--SP - Sponsored
		--UA - Unavailable
		--UN - Unknown
	  , case core.sponsorship_status
			when 'Available' then 'AV'
			when 'Check Materials' then 'CM'
			when 'Enrolled' then 'EN'
			when 'Pre-Sponsored' then 'PS'
			when 'Reinstateable' then 'RE'
			when 'Reserved' then 'RV'
			when 'Sponsored' then 'SP'
			when 'Unavailable' then 'UA'
			when 'Unknown' then 'UN'
			else 'UN' end								as SponsorshipStatusFl
	  , core.co_name									as Country
	  , coalesce(core.local_partner_name, 'Unknown')	as LocalPartner
	  , coalesce(core.community_name, 'Unknown')		as Community
	  , coalesce(core.village, 'Unknown')				as Village
      , cast(core.date_opened as date)					as DateOpened_CC
      , cast(core.date_closed as date)					as DateClosed_CC
	  , cast(core.date_modified as datetime2(0))		as DateModified_CC
	  , cast( case when core.created_date = '#NULL!' then null
			when core.created_date = '30/11/-0001' then null
			when len(core.created_date) = 10
				then core.created_date end as date)		as DateCreated_CC
	  , case when
			row_number() over (partition by core.child_id order by cast(core.date_modified as datetime2(0)) desc) = 1
			then 1
			else 0 end									as LeadRecordByChildId
  from [stg].[all_child_cases] core

-- Discard invalid records
where 1=1
and (
	core.community_name not like 'test%'
	or core.community_name is null
)
and core.co_name is not null
and core.child_id > 0

union

select '0','0',-1,'',0,'','','',null,null,null,null,'','','','','','','','','','','',null,null,null,null,1