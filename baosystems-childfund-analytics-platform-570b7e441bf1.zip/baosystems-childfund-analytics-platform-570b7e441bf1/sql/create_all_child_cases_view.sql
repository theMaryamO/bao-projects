/********************************************************************************
	Union of all Case Extracts, the primary source of case attributes

	v1 - 20211207 - nevens@baosystems.com
	Naive join of all case extracts

********************************************************************************/

create or alter view stg.all_child_cases_view as
select id
	, case_name
	, closed
	, source_module
	, date_opened
	, date_closed
	, date_modified
	, json_value( properties, '$.child_ID')				as child_id
	, json_value( properties, '$."CPR"')				as cpr		
	, json_value( properties, '$.educational_level')	as education_level
	, json_value( properties, '$.ethnicity')			as ethnicity
	, json_value( properties, '$.child_date_of_birth')	as child_date_of_birth
	, json_value( properties, '$.age')					as age
	, json_value( properties, '$.language')				as language
	, json_value( properties, '$.local_partner_id')		as local_partner_id
	, json_value( properties, '$.local_partner_name')	as local_partner_name	
	, json_value( properties, '$.sex')					as sex
	, json_value( properties, '$.child_name')			as child_name
	, json_value( properties, '$.child_first_name')		as child_first_name
	, json_value( properties, '$.child_last_name')		as child_last_name
	, json_value( properties, '$.region')				as region
	, json_value( properties, '$.co_id')				as co_id
	, json_value( properties, '$.co_name')				as co_name
	, json_value( properties, '$.community_id')			as community_id
	, json_value( properties, '$.community_name')		as community_name
	, json_value( properties, '$.village')				as village
	, json_value( properties, '$.national_sponsorship') as national_sponsorship
	, json_value( properties, '$.sponsorship_status')	as sponsorship_status	
	, json_value( properties, '$.enrollment_status')	as enrollment_status
	, json_value( properties, '$.created_date')			as created_date

from
(
	select 'kenya-fy21-me' as source_module	, * from [dbo].[kenya_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'ethiopia-fy21-me'				, * from [dbo].[ethiopia_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'india-fy21-me'			    	, * from [dbo].[india_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'indonesia-fy21-me'				, * from [dbo].[indonesia_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'philippines-fy21-me'			, * from [dbo].[philippines_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'senegal-fy21-me'				, * from [dbo].[senegal_guinea_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'sri-lanka-fy21-me'				, * from [dbo].[sri_lanka_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'uganda-fy21-me'					, * from [dbo].[uganda_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'us-fy21-me'					    , * from [dbo].[us_programs_fy21_me_survey_cc] where case_type = 'child'
	union all
	select 'zambia-fy21-me'			    	, * from [dbo].[zambia_mozambique_fy21_me_survey_cc] where case_type = 'child'
	union all
	-- No need to also get americas_fy21 as the case table is identical
	select 'americas-fy22-me'		    	, * from [dbo].[americas_fy22_me_survey_cc] where case_type = 'child'
	union all
	select 'gambia-annual-me'			   	, * from [dbo].[gambia_annual_me_survey_cc] where case_type = 'child'
) u