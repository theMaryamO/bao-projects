drop table if exists dim.junk;

create table dim.junk (
	JunkKey		int identity not null,
	Dimension	varchar(50) not null,
	Code		varchar(100) null,
	Display		varchar(100) null,
	LongName	varchar(100)	null,
	[Order]		int null
);

insert into dim.junk (
	Dimension,
	Code,
	Display,
	LongName,
	[Order]
) values
( 'Lifestage',		NULL,		'',	'', 0 ),
( 'Lifestage',		'LS1', 'LS1',	'Lifestage 1', 1),
( 'Lifestage',		'LS2', 'LS2', 'Lifestage 2'	, 2),
( 'Lifestage',		'LS3', 'LS3', 'Lifestage 3'	, 3),

( 'Received Care', NULL, '', '', null ),
( 'Received Care', 'care_at_home', 'Received care at home only', '', null ),
( 'Received Care', 'nothing', 'Did not receive care', '', null ),
( 'Received Care', 'care_from_healthprofessional', 'Received care from health professional only', '', null ),
( 'Received Care', 'not_suredont_know', 'Other', '', null ),
( 'Received Care', 'both', 'Both', '', null ),
( 'Received Care', 'chose_not_to_answer', 'Other', '', null ),

( 'How Soon Care', NULL, '', '', null ),
( 'How Soon Care', 'within_a_week', 'More than 2 days', '', null ),
( 'How Soon Care', '1_week_or_longer', 'More than 2 days', '', null ),
( 'How Soon Care', 'within_2_days', 'Within 2 days', '', null ),
( 'How Soon Care', 'not_suredont_know', 'Other', '', null ),
( 'How Soon Care', 'within_24_hours', 'Within 24 hours', '', null ),
( 'How Soon Care', 'chose_not_to_answer', 'Other', '', null ),

( 'Health Need', NULL, '', '', null ),
( 'Health Need', 'not_suredont_know', 'Not sure/don''t know', '', null ),
( 'Health Need', 'no', 'No', '', null ),
( 'Health Need', 'chose_not_to_answer', 'Chose not to answer', '', null ),
( 'Health Need', 'yes', 'Yes', '', null ),
( 'Health Need', 'not_sure_dont_know', 'Not sure/don''t know', '', null ),

( 'Water Source', NULL, '', '', null ),
( 'Water Source', 'from_a_river_or_a_spring', 'River or spring', '', null ),
( 'Water Source', 'from_a_well', 'Well', '', null ),
( 'Water Source', 'from_a_communal_tap', 'Communal tap', '', null ),
( 'Water Source', 'other', 'Other', '', null ),
( 'Water Source', 'yes', 'Tap in the house', '', null ),

( 'Times Eaten', NULL, '', '', null ),
( 'Times Eaten', 'once', 'Once', '', null ),
( 'Times Eaten', 'twice', 'Twice', '', null ),
( 'Times Eaten', 'three_or_more_times', '3 or more', '', null ),
( 'Times Eaten', 'i_did_not_eat_in_the_last_24_hours', 'Did not eat', '', null )