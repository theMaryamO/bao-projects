create or alter proc dbo.rebuild_global_me_survey_table as
begin

drop table if exists [stg].[all_global_me_survey];

select *
into [stg].[all_global_me_survey]
from [stg].[all_global_me_survey_view];

drop index if exists [ccix_all_global_me_survey]
on [stg].[all_global_me_survey];

create clustered columnstore index [ccix_all_global_me_survey]
on [stg].[all_global_me_survey];

end