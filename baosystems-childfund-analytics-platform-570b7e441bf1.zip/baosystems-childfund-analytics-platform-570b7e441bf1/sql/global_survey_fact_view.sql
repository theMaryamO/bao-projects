/********************************************************************************

	Childfund Education Fact in BAO AP
	Target database = Azure Sql Database

	Traditional fact table based on the union of annual m&e surveys
	retrieved from CommCare.

********************************************************************************/
create or alter view [fact].[global_survey]	as
select coalesce(child.ChildKey, '0')	as ChildKey
      ,coalesce(loc.LocationKey, -1)	as LocationKey
	  ,coalesce(
		cast(
			format(
				cast(left(fact.submission_received_on, 10) as date) 
				, 'yyyyMMdd'
			)
		 as int )
	  , -1)								as SubmissionDateKey
	  ,FiscalYear
	  ,coalesce(ls.LifestageKey, -1)	as LifestageKey
	  ,coalesce(cw.ConductedWithKey, -1)
										as ConductedWithKey
	  ,coalesce(st.SchoolTypeKey, -1)	as SchoolTypeKey
	  ,coalesce(noschool.ReasonNotInSchoolKey, -1)		
	  									as ReasonNotInSchoolKey
	  ,coalesce(hn.JunkKey, -1)			as HealthNeedKey
	  ,coalesce(rc.JunkKey, -1)			as ReceivedCareKey
	  ,coalesce(hsc.JunkKey, -1)		as HowSoonCareKey
	  ,coalesce(water.JunkKey, -1)		as WaterSourceKey
	  ,coalesce(eat.JunkKey, -1)		as TimesEatenKey
	  ,cast([age] as tinyint)			as SurveyAge
      ,case
		when cast([age] as tinyint) >= map.LowerAge 
			and cast([age] as tinyint) <= map.UpperAge
		then 'Yes' 
		else 'No' 
		end								as IsCompulsoryAge
      ,case present_interview
	  	  when 'yes' then 'Yes'
		  when 'no' then 'No'
		  when 'refuses_interview' then 'Refused'
		  else 'Unknown' end			as IsPresentInterview
	  ,case child_in_school
		when 'no' then 'No'
		when 'yes' then 'Yes'
		when 'chose_not_to_answer' then 'Chose Not to Answer'
		when 'not_suredont_know' then 'Not Sure/Don''t Know'
		else 'Unknown' end
										as IsChildInSchool
	  ,case internet_at_home
	  	  when 'yes' then 'Yes'
		  when 'no' then 'No'
		  else 'NA' end			as IsInternetAtHome
	  ,case online_learning
	  	  when 'yes' then 'Yes'
		  when 'no' then 'No'
		  else 'NA' end			as IsOnlineLearning
	  ,case thrive_positive_view
	  	  when 'yes' then 'Yes'
		  when 'no' then 'No'
		  else 'NA' end			as IsThrivePositiveView
	  ,case is_there_drinking_water
		when 'no' then 'No'
		when 'yes' then 'Yes'
		when 'not_suredont_know' then 'Not Sure/Don''t Know'
		else 'NA' end
										as IsDrinkingWater
	  ,case do_you_have_access_to_a_toilet_or_latrine_at_or_near_home
		when 'no' then 'No'
		when 'yes' then 'Yes'
		when 'not_suredont_know' then 'Not Sure/Don''t Know'
		else 'NA' end
										as IsToiletAccess
	  ,case do_you_have_a_place_to_wash_your_hands_at_or_near_home
		when 'no' then 'No'
		when 'yes' then 'Yes'
		when 'not_suredont_know' then 'Not Sure/Don''t Know'
		else 'NA' end
										as IsWashHands

	  ,case [hhs1a] when 'often' then 2 when 'rarely' then 1 when 'sometimes' then 1 else 0 end
		+ case [hhs1] when 'yes' then 1 else 0 end
		+ case [hhs2a] when 'often' then 2 when 'rarely' then 1 when 'sometimes' then 1 else 0 end
		+ case [hhs2] when 'yes' then 1 else 0 end
		+ case [hhs3a] when 'often' then 2 when 'rarely' then 1 when 'sometimes' then 1	else 0 end
		+ case [hhs3] when 'yes' then 1 else 0 end
										as HungerScaleScore

	  , case when computing_device like '%smartphone%' then 1 else 0 end UsesSmartphone
	  , case when computing_device like '%tablet_or_similar_internet-connected_device%' then 1 else 0 end UsesTablet
	  , case when computing_device like '%desktop_computer_or_laptop%' then 1 else 0 end UsesComputer

	  , case when dietary_diversity like '%grains%' then 1 else 0 end DietGrains
	  , case when dietary_diversity like '%beans_and_nuts%' then 1 else 0 end DietBeansAndNuts
	  , case when dietary_diversity like '%eggs%' then 1 else 0 end DietEggs
	  , case when dietary_diversity like '%root_vegetables%' then 1 else 0 end DietRootVegetables
	  , case when dietary_diversity like '%vegetables%' and dietary_diversity not like '%root_vegetables%' then 1 else 0 end DietVegetables
	  , case when dietary_diversity like '%dairy_products%' then 1 else 0 end DietDairyProducts
	  , case when dietary_diversity like '%meat%' then 1 else 0 end DietMeat
	  , case when dietary_diversity like '%fruits%' then 1 else 0 end DietFruit
	  , case when dietary_diversity like '%cofee_tea_condiments_and_other%' then 1 else 0 end DietCondiments
	  , case when dietary_diversity like '%oil_fat_butter%' then 1 else 0 end DietOilFatButter
	  , case when dietary_diversity like '%seafood%' then 1 else 0 end DietSeafood
	  , case when dietary_diversity like '%sugar_or_honey%' then 1 else 0 end DietSweeteners
	  , (select value from string_split( meta_location, ' ', 1 ) where ordinal = 1) as Latitude
	  , (select value from string_split( meta_location, ' ', 1 ) where ordinal = 2) as Longitude
	  
	  , case when (cp2_ls1 like '%Other_family%' or cp2_ls2_ls3 like '%parent_relative%') then 1 else 0 end ChildProtectionReportParentOrRelative
	  , case when (cp2_ls1 like '%police%' or cp2_ls2_ls3 like '%police%') then 1 else 0 end ChildProtectionReportPolice
	  , case when (cp2_ls1 like '%school_staff%' or cp2_ls2_ls3 like '%school_staff%') then 1 else 0 end ChildProtectionReportSchoolStaff
	  , case when (cp2_ls1 like '%health_professional%' or cp2_ls2_ls3 like '%health_professional%') then 1 else 0 end ChildProtectionReportHealthProfessional
	  , case when (cp2_ls1 like '%friend%' or cp2_ls2_ls3 like '%friend%') then 1 else 0 end ChildProtectionReportFriend
	  , case when (cp2_ls2_ls3 like '%children_youth_group%') then 1 else 0 end ChildProtectionReportYouthGroup
	  , case when (cp2_ls1 like '%community_group%' or cp2_ls2_ls3 like '%community_group%') then 1 else 0 end ChildProtectionReportCommunityGroup
	  , case when (cp2_ls1 like '%village_tribal_council%' or cp2_ls2_ls3 like '%village_tribal_council%') then 1 else 0 end ChildProtectionReportVillageCouncil
	  , case when (cp2_ls1 like '%religious_group_leader%' or cp2_ls2_ls3 like '%religious_group_leader%') then 1 else 0 end ChildProtectionReportReligiousLeader
	  , case when (cp2_ls1 like '%formal_child_protection_system%' or cp2_ls2_ls3 like '%formal_child_protection_system%') then 1 else 0 end ChildProtectionReportChildProtectionSystem
	  , case when (cp2_ls1 COLLATE SQL_Latin1_General_Cp1_CS_AS like '%other%'
				or cp2_ls2_ls3 COLLATE SQL_Latin1_General_Cp1_CS_AS like '%other%') then 1 else 0 end ChildProtectionReportOther
	  , case 
	     when (cp1 = 'yes' AND cp3 = 'yes') then 'Yes' 
	     when (cp1 is null and cp3 is null) then 'NA'
	     else 'No' end 
										as ChildCaregiverKnowsWhereToReportHarm
	  , coalesce( case cp1
		 when 'no' then 'No'
		 when 'yes' then 'Yes'
		 when 'chose_not_to_answer' then 'Chose Not to Answer'
		 when 'choice28' then 'No'
		 when 'choice29' then 'Not Sure'
		 else cp1 end, 'NA' )
										as KnowsWhereToReportHarm
	  , coalesce( case cp3
		 when 'no' then 'No'
		 when 'yes' then 'Yes'
		 when 'chose_not_to_answer' then 'Chose Not to Answer'
		 when 'not_sure' then 'Not Sure'
		 else cp3 end, 'NA' )
										as WouldReportHarm

FROM [stg].[all_global_me_survey] fact

-- join the fact table to the location table to
--   bring in the location foreign key
left join dim.location_view loc
	on fact.co_name = loc.Country
	and fact.community_name = loc.Community

-- join the fact table to the child table to
--   bring in the child foreign key	
left join dim.child_view child
	on fact.case_id = child.caseid

-- join in lifestage dimension
left join dim.lifestage ls
	on fact.lifestage = ls.lifestage

-- join in the compulsory age map to provide age thresholds
left join stg.region_and_compulsory_age_map map
	on fact.co_name = map.Country

-- join in SchoolType dimension
left join dim.school_type st
	on fact.school_type = st.SchoolTypeCode

-- join in ReasonNotInSchool dimension
left join dim.reason_not_in_school noschool
	on fact.reason_not_attending_school = noschool.ReasonNotInSchoolDetail

-- join 'Conducted With' dimension
left join dim.conducted_with cw
	on fact.conducted_with = cw.ConductedWithCode

left join dim.junk hn
	on fact.health_need = hn.Code
		and hn.Dimension = 'Health Need'

left join dim.junk rc
	on fact.received_care = rc.Code
		and rc.Dimension = 'Received Care'

left join dim.junk hsc
	on fact.how_soon_care = hsc.Code
		and hsc.Dimension = 'How Soon Care'

left join dim.junk water
	on fact.what_is_your_main_source_of_drinking_water = water.Code
		and water.Dimension = 'Water Source'

left join dim.junk eat
	on fact.in_the_last_24_hours_how_many_times_have_you_eaten = eat.Code
		and eat.Dimension = 'Times Eaten';