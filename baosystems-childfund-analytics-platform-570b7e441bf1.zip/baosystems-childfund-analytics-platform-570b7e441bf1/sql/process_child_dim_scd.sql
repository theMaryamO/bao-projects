CREATE OR ALTER   proc [dbo].[process_child_dim_scd] as
begin

declare @now datetime2(7) = SYSUTCDATETIME();

insert into dim.child
(
	[CaseId]
	,[ChildId]
	,[SourceModule]
	,[GlobalSurvey]
	,[Closed]
	,[ChildName]
	,[FirstName]
	,[LastName]
	,[Nickname]
	,[Birthdate]
	,[CurrentAge]
	,[RegistrationAge]
	,[Sex]
	,[SexFl]
	,[Ethnicity]
	,[Language]
	,[Education]
	,[SponsorshipStatus]
	,[SponsorshipStatusFl]
	,[Country]
	,[NationalOffice]
	,[LocalPartner]
	,[Community]
	,[Village]
	,[DateOpened_CC]
	,[DateClosed_CC]
	,[DateModified_CC]
	,[DateCreated_SF]
)
select
	coalesce([CaseId], 'invalid')
	,coalesce([ChildId], -1)
	,coalesce([SourceModule], 'unknown')
	,coalesce([GlobalSurvey], 0)
	,coalesce([Closed], 0)
	,[ChildName]
	,[FirstName]
	,[LastName]
	,[Nickname]
	,[Birthdate]
	,[CurrentAge]
	,[RegistrationAge]
	,[Sex]
	,[SexFl]
	,[Ethnicity]
	,[Language]
	,[Education]
	,[SponsorshipStatus]
	,[SponsorshipStatusFl]
	,[Country]
	,[NationalOffice]
	,[LocalPartner]
	,[Community]
	,[Village]
	,[DateOpened_CC]
	,[DateClosed_CC]
	,[DateModified_CC]
	,[DateCreated_SF]
	from
	(
		merge dim.child as target
		using stg.child as source
		on source.CaseId = target.CaseId

		-- existing record match = DEMOTE existing record
		when matched then
			update
				set ValidToDate = @now
					, IsCurrent = 0
					, ModifiedDate = @now

		-- new records = INSERT
		when not matched by target then
			insert ( 
			  [CaseId]
			  ,[ChildId]
			  ,[SourceModule]
			  ,[GlobalSurvey]
			  ,[Closed]
			  ,[ChildName]
			  ,[FirstName]
			  ,[LastName]
			  ,[Nickname]
			  ,[Birthdate]
			  ,[CurrentAge]
			  ,[RegistrationAge]
			  ,[Sex]
			  ,[SexFl]
			  ,[Ethnicity]
			  ,[Language]
			  ,[Education]
			  ,[SponsorshipStatus]
			  ,[SponsorshipStatusFl]
			  ,[Country]
			  ,[NationalOffice]
			  ,[LocalPartner]
			  ,[Community]
			  ,[Village]
			  ,[DateOpened_CC]
			  ,[DateClosed_CC]
			  ,[DateModified_CC]
			  ,[DateCreated_SF]
			  )
		values
		(
			  coalesce(source.[CaseId], 'invalid')
			  ,coalesce(source.[ChildId], -1)
			  ,coalesce(source.[SourceModule], 'unknown')
			  ,coalesce(source.[GlobalSurvey], 0)
			  ,coalesce(source.[Closed], 0)
			  ,source.[ChildName]
			  ,source.[FirstName]
			  ,source.[LastName]
			  ,source.[Nickname]
			  ,source.[Birthdate]
			  ,source.[CurrentAge]
			  ,source.[RegistrationAge]
			  ,source.[Sex]
			  ,source.[SexFl]
			  ,source.[Ethnicity]
			  ,source.[Language]
			  ,source.[Education]
			  ,source.[SponsorshipStatus]
			  ,source.[SponsorshipStatusFl]
			  ,source.[Country]
			  ,source.[NationalOffice]
			  ,source.[LocalPartner]
			  ,source.[Community]
			  ,source.[Village]
			  ,source.[DateOpened_CC]
			  ,source.[DateClosed_CC]
			  ,source.[DateModified_CC]
			  ,source.[DateCreated_SF]
		)

	output $action
		,source.[CaseId]
		,source.[ChildId]
		,source.[SourceModule]
		,source.[GlobalSurvey]
		,source.[Closed]
		,source.[ChildName]
		,source.[FirstName]
		,source.[LastName]
		,source.[Nickname]
		,source.[Birthdate]
		,source.[CurrentAge]
		,source.[RegistrationAge]
		,source.[Sex]
		,source.[SexFl]
		,source.[Ethnicity]
		,source.[Language]
		,source.[Education]
		,source.[SponsorshipStatus]
		,source.[SponsorshipStatusFl]
		,source.[Country]
		,source.[NationalOffice]
		,source.[LocalPartner]
		,source.[Community]
		,source.[Village]
		,source.[DateOpened_CC]
		,source.[DateClosed_CC]
		,source.[DateModified_CC]
		,source.[DateCreated_SF]
)

as changes
(
	   action
	  ,[CaseId]
      ,[ChildId]
      ,[SourceModule]
      ,[GlobalSurvey]
      ,[Closed]
      ,[ChildName]
      ,[FirstName]
      ,[LastName]
      ,[Nickname]
      ,[Birthdate]
      ,[CurrentAge]
      ,[RegistrationAge]
      ,[Sex]
      ,[SexFl]
      ,[Ethnicity]
      ,[Language]
      ,[Education]
      ,[SponsorshipStatus]
      ,[SponsorshipStatusFl]
      ,[Country]
      ,[NationalOffice]
      ,[LocalPartner]
      ,[Community]
      ,[Village]
      ,[DateOpened_CC]
      ,[DateClosed_CC]
      ,[DateModified_CC]
      ,[DateCreated_SF]
)
where action = 'UPDATE';
end