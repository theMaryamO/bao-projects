create or alter proc dbo.rebuild_all_child_cases_table as
begin

drop table if exists [stg].[all_child_cases];

select *
into [stg].[all_child_cases]
from [stg].[all_child_cases_view];

drop index if exists [ccix_all_child_cases]
on [stg].[all_child_cases];

create clustered columnstore index [ccix_all_child_cases]
on [stg].[all_child_cases];

end